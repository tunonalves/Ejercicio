def dividir():
    pass