def multiplicar():
    pass