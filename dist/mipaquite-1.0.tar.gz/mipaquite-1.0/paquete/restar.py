def restar():
    pass