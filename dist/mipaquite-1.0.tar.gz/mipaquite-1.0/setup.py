from setuptools import setup

setup(
    name='mipaquite',
    version='1.0',
    description='mi primer paquite',
    author='Federico',
    packages=['paquete'],
    
)